from math import prod
from typing import Tuple

import numpy as np
import torch
from timm.models.layers import to_2tuple

from torch import nn
import math
from torch.nn import functional as F
from einops import rearrange as rearrange
from abc import ABC

def bchw_to_bhwc(x: torch.Tensor) -> torch.Tensor:
    """Permutes a tensor from the shape (B, C, H, W) to (B, H, W, C)."""
    return x.permute(0, 2, 3, 1)


def bhwc_to_bchw(x: torch.Tensor) -> torch.Tensor:
    """Permutes a tensor from the shape (B, H, W, C) to (B, C, H, W)."""
    return x.permute(0, 3, 1, 2)


def bchw_to_blc(x: torch.Tensor) -> torch.Tensor:
    """Rearrange a tensor from the shape (B, C, H, W) to (B, L, C)."""
    return x.flatten(2).transpose(1, 2)


def blc_to_bchw(x: torch.Tensor, x_size: Tuple) -> torch.Tensor:
    """Rearrange a tensor from the shape (B, L, C) to (B, C, H, W)."""
    B, L, C = x.shape
    return x.transpose(1, 2).view(B, C, *x_size)


def blc_to_bhwc(x: torch.Tensor, x_size: Tuple) -> torch.Tensor:
    """Rearrange a tensor from the shape (B, L, C) to (B, H, W, C)."""
    B, L, C = x.shape
    return x.view(B, *x_size, C)

def window_partition(x, window_size: Tuple[int, int]):
    """
    Args:
        x: (B, H, W, C)
        window_size (int): window size

    Returns:
        windows: (num_windows*B, window_size, window_size, C)
    """
    B, H, W, C = x.shape
    x = x.view(
        B, H // window_size[0], window_size[0], W // window_size[1], window_size[1], C
    )
    windows = (
        x.permute(0, 1, 3, 2, 4, 5)
        .contiguous()
        .view(-1, window_size[0], window_size[1], C)
    )
    return windows


def window_reverse(windows, window_size: Tuple[int, int], img_size: Tuple[int, int]):
    """
    Args:
        windows: (num_windows * B, window_size[0], window_size[1], C)
        window_size (Tuple[int, int]): Window size
        img_size (Tuple[int, int]): Image size

    Returns:
        x: (B, H, W, C)
    """
    H, W = img_size
    B = int(windows.shape[0] / (H * W / window_size[0] / window_size[1]))
    x = windows.view(
        B, H // window_size[0], W // window_size[1], window_size[0], window_size[1], -1
    )
    x = x.permute(0, 1, 3, 2, 4, 5).contiguous().view(B, H, W, -1)
    return x


class FeaFuse(nn.Module):
    def __init__(self, in_channels, num_fea=2, reduction=8):
        super().__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.se = nn.Sequential(
            nn.Conv2d(in_channels, in_channels//reduction, kernel_size=1, padding=0, bias=False),
            nn.LeakyReLU(0.2)
        )
        self.num = num_fea
        for i in range(num_fea):
            block = nn.Conv2d(in_channels//reduction, in_channels, kernel_size=1, padding=0, bias=False)
            setattr(self, 'trans' + str(i), block)
        self.softmax= nn.Softmax(dim=1)

    def forward(self, batch):
        bs = batch[0].size(0)
        ch = batch[0].size(1)
        batch = torch.cat(batch, dim=1).view(bs, self.num,  ch, batch[0].size(2), batch[0].size(3))
        temp = torch.sum(batch, dim=1)
        temp = self.avg_pool(temp)
        temp = self.se(temp)

        attn0 = self.trans0(temp)
        attn1 = self.trans1(temp)
       

        battn = torch.cat([attn0, attn1], dim=1).view(bs, self.num, ch, 1, 1)
        battn = self.softmax(battn)
        feature = torch.sum(battn * batch, dim=1)
        return feature
    

class LayerNormFunction(torch.autograd.Function):

    @staticmethod
    def forward(ctx, x, weight, bias, eps):
        ctx.eps = eps
        N, C, H, W = x.size()
        mu = x.mean(1, keepdim=True)
        var = (x - mu).pow(2).mean(1, keepdim=True)
        y = (x - mu) / (var + eps).sqrt()
        ctx.save_for_backward(y, var, weight)
        y = weight.view(1, C, 1, 1) * y + bias.view(1, C, 1, 1)
        return y

    @staticmethod
    def backward(ctx, grad_output):
        eps = ctx.eps

        N, C, H, W = grad_output.size()
        y, var, weight = ctx.saved_variables
        g = grad_output * weight.view(1, C, 1, 1)
        mean_g = g.mean(dim=1, keepdim=True)

        mean_gy = (g * y).mean(dim=1, keepdim=True)
        gx = 1. / torch.sqrt(var + eps) * (g - y * mean_gy - mean_g)
        return gx, (grad_output * y).sum(dim=3).sum(dim=2).sum(dim=0), grad_output.sum(dim=3).sum(dim=2).sum(
            dim=0), None

class LayerNorm2d(nn.Module):

    def __init__(self, channels, eps=1e-6):
        super(LayerNorm2d, self).__init__()
        self.register_parameter('weight', nn.Parameter(torch.ones(channels)))
        self.register_parameter('bias', nn.Parameter(torch.zeros(channels)))
        self.eps = eps

    def forward(self, x):
        return LayerNormFunction.apply(x, self.weight, self.bias, self.eps)


class SeparableConv(nn.Sequential):
    def __init__(self, in_channels, out_channels, kernel_size, stride, bias, args=None):
        m = [
            nn.Conv2d(
                in_channels,
                in_channels,
                kernel_size,
                stride,
                kernel_size // 2,
                groups=in_channels,
                bias=bias,
            )
        ]
        # if args.separable_conv_act:
        #     m.append(nn.GELU())
        m.append(nn.Conv2d(in_channels, out_channels, 1, 1, 0, bias=bias))
        super(SeparableConv, self).__init__(*m)


class QKVProjection(nn.Module):
    def __init__(self, dim, qkv_bias):
        super(QKVProjection, self).__init__()
    
        self.body = SeparableConv(dim, dim * 3, 3, 1, qkv_bias)

    def forward(self, x, x_size):
        # if self.proj_type == "separable_conv":
      
        x = self.body(x)
        # if self.proj_type == "separable_conv":
        x = bchw_to_blc(x)
        return x




#***********************************

class Glolbal_Attention(nn.Module):
    def __init__(self, in_ch=256, num_head=4, bias=False):
        super().__init__()
        self.head = num_head
        self.query = nn.Sequential(
            nn.Conv2d(in_channels=in_ch, out_channels=in_ch, kernel_size=1, padding=0),
            nn.Conv2d(in_channels=in_ch, out_channels=in_ch, kernel_size=3, padding=1,groups=in_ch,bias=bias),
            nn.Softplus()
        )


        self.key = nn.Sequential(
            nn.Conv2d(in_channels=in_ch, out_channels=in_ch, kernel_size=1, padding=0),
            nn.Conv2d(in_channels=in_ch, out_channels=in_ch, kernel_size=3, padding=1,groups=in_ch,bias=bias),
            nn.Softplus()
            # nn.Conv2d(in_channels=in_ch, out_channels=in_ch, kernel_size=1, padding=0)
        )

        self.value = nn.Sequential(
            nn.Conv2d(in_channels=in_ch, out_channels=in_ch, kernel_size=1, padding=0,bias=bias),
            nn.Conv2d(in_channels=in_ch, out_channels=in_ch, kernel_size=3, padding=1,groups=in_ch,bias=bias))
        #nn.Conv2d(in_channels=in_ch, out_channels=in_ch, kernel_size=1, padding=0)

        self.output_linear = nn.Conv2d(in_channels=in_ch, out_channels=in_ch, kernel_size=1)
        # self.norm = nn.InstanceNorm2d(num_features=in_ch)

    def forward(self, x):
        """
        x: b * c * h * w
        """
        # H, W = x_size
        # B, L, C = qkv.shape
        # qkv = qkv.view(B, H, W, C)
        # qkv = qkv.reshape(B, L, 3, self.head, -1).permute(2, 0, 3, 1, 4)
        # q, k, v = qkv[0], qkv[1], qkv[2] # B, HEAD_NUM, L, c

        # x = self.norm(x)
        Ba, Ca, He, We = x.size()
        q = self.query(x)
        k = self.key(x)
        v = self.value(x)
        num_per_head = Ca // self.head

        q = rearrange(q, 'b (head c) h w -> b head c (h w)', head=self.head)  # B * head * c * N
        k = rearrange(k, 'b (head c) h w -> b head c (h w)', head=self.head)  # B * head * c * N
        v = rearrange(v, 'b (head c) h w -> b head c (h w)', head=self.head)  # B * head * c * N
        kv = torch.matmul(k, v.transpose(-2, -1))
        # kv = torch.einsum('bhcn, bhdn -> bhcd', k, v)
        z = torch.einsum('bhcn,bhc -> bhn', q, k.sum(dim=-1)).contiguous() / math.sqrt(num_per_head)
        z = 1.0 / (z + He * We)  # b h n
        out = torch.einsum('bhcn, bhcd-> bhdn', q, kv).contiguous()
        out = out / math.sqrt(num_per_head)  # b h c n
        out = out * z.unsqueeze(2)
        out = rearrange(out, 'b head c (h w) -> b (head c) h w', h=He)  # b,C,h,w
        if Ca < 48:
            pass
        else:
            out = self.output_linear(out)
        # out = out.view(Ba, Ca, -1).transpose(1,2) # b, l,c 
        return out  # b,c,h,w



###############window attention#####################
# 
    
class Attention(ABC, nn.Module):
    def __init__(self):
        super(Attention, self).__init__()

    def attn(self, q, k, v, reshape=True):
        # q, k, v: # nW*B, H, wh*ww, dim
        # cosine attention map
        B_, _, H, head_dim = q.shape
       
        attn = F.normalize(q, dim=-1) @ F.normalize(k, dim=-1).transpose(-2, -1)
        # attn = attn_transform(attn, table, index, mask)
        # attention
        attn = self.softmax(attn)
        attn = self.attn_drop(attn)
        x = attn @ v  # B_, H, N1, head_dim
        if reshape:
            x = x.transpose(1, 2).reshape(B_, -1, H * head_dim)
        # B_, N, C
        return x


class WindowAttention(Attention):
    r"""Window attention. QKV is the input to the forward method.
    Args:
        num_heads (int): Number of attention heads.
        attn_drop (float, optional): Dropout ratio of attention weight. Default: 0.0
        pretrained_window_size (tuple[int]): The height and width of the window in pre-training.
    """

    def __init__(
        self,
        dim,
        window_size,
        num_heads=3,
        attn_drop=0.0,
        args=None,
    ):

        super(WindowAttention, self).__init__()
       
        self.window_size = [window_size, window_size] 
      
        self.num_heads = num_heads
      
        self.qkv =  QKVProjection(dim, qkv_bias=True)
        self.attn_drop = nn.Dropout(attn_drop)
        self.softmax = nn.Softmax(dim=-1)

    def forward(self, x, x_size):
        """
        Args:
            qkv: input QKV features with shape of (B, L, 3C)
            x_size: use x_size to determine whether the relative positional bias table and index
            need to be regenerated.
        """
        H, W = x_size
        qkv = self.qkv(x, x_size)  # b,l,c
        B, L, C = qkv.shape
        qkv = qkv.view(B, H, W, C)
        
        # partition windows
        qkv = window_partition(qkv, self.window_size)  # nW*B, wh, ww, C
        qkv = qkv.view(-1, prod(self.window_size), C)  # nW*B, wh*ww, C

        B_, N, _ = qkv.shape
        qkv = qkv.reshape(B_, N, 3, self.num_heads, -1).permute(2, 0, 3, 1, 4)
        q, k, v = qkv[0], qkv[1], qkv[2]  # nW*B, H, wh*ww, dim

        # attention
        x = self.attn(q, k, v)

        # merge windows
        x = x.view(-1, *self.window_size, C//3)
        x = window_reverse(x, self.window_size, x_size)  # B, H, W, C

        # x = x.view(B, L, C//3)

        return x

    def extra_repr(self) -> str:
        return (
            f"window_size={self.window_size}" #, shift_size={self.shift_size}, "
            # f"pretrained_window_size={self.pretrained_window_size}, num_heads={self.num_heads}"
        )

    def flops(self, N):
        pass



class ChannelAttention(nn.Module):
    """Channel attention used in RCAN.
    Args:
        num_feat (int): Channel number of intermediate features.
        reduction (int): Channel reduction factor. Default: 16.
    """

    def __init__(self, num_feat, reduction=16):
        super(ChannelAttention, self).__init__()
        self.attention = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(num_feat, num_feat // reduction, 1, padding=0),
            nn.ReLU(inplace=True),
            nn.Conv2d(num_feat // reduction, num_feat, 1, padding=0),
            nn.Sigmoid(),
        )

    def forward(self, x):
        y = self.attention(x)
        return x * y


class CAB(nn.Module):
    def __init__(self, num_feat, compress_ratio=4, reduction=18):
        super(CAB, self).__init__()

        self.cab = nn.Sequential(
            nn.Conv2d(num_feat, num_feat // compress_ratio, 3, 1, 1),
            nn.GELU(),
            nn.Conv2d(num_feat // compress_ratio, num_feat, 3, 1, 1),
            ChannelAttention(num_feat, reduction),
        )
        # dw_channel = num_feat  * 2
        # self.conv1 = nn.Conv2d(in_channels=num_feat , out_channels=dw_channel, kernel_size=1, padding=0, stride=1, groups=1, bias=True)
        # self.conv2 = nn.Conv2d(in_channels=dw_channel, out_channels=dw_channel, kernel_size=3, padding=1, stride=1, groups=dw_channel,
        #                        bias=True)
        # self.conv3 = nn.Conv2d(in_channels=dw_channel // 2, out_channels=num_feat , kernel_size=1, padding=0, stride=1, groups=1, bias=True)
        
        # # Simplified Channel Attention
        # self.sca = nn.Sequential(
        #     nn.AdaptiveAvgPool2d(1),
        #     nn.Conv2d(in_channels=dw_channel // 2, out_channels=dw_channel // 2, kernel_size=1, padding=0, stride=1,
        #               groups=1, bias=True),
        # )

    def forward(self, x, x_size):
        x = self.cab(x)  
       
        return x #bchw_to_blc(x).contiguous()  # b, l,c 